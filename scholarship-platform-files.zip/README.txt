SCHOLARSHIP PLATFORM FILES

Files:
- index.html: public applicant registration page
- admin.html: private admin sign-in and applications list

Supabase project:
https://slaztmnqjkfhldczvmuq.supabase.co

Important:
1. These are website files, not a live hosted website.
2. Keep admin.html private in use; only the owner should sign in.
3. The public page uses the Supabase publishable key, which is designed for browser use. Never add a service_role key to website files.
4. The admin page expects the admin-applications Edge Function to return an "applications" array.
5. Before public launch, add a proper privacy notice, eligibility rules, selection process, contact details, CAPTCHA/robust rate limiting, and confirm all scholarship claims and logo usage comply with the authorization.
6. Do not ask applicants for passwords, banking PINs, or codes issued by WhatsApp, email providers, or other services.
7. Host index.html as the public homepage. Restrict or protect admin.html through hosting rules where possible; the database function still enforces administrator authorization.
